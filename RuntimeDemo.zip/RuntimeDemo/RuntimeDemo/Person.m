

//
//  Person.m
//  RuntimeDemo
//
//  Created by 刘鑫 on 2018/12/19.
//  Copyright © 2018 刘鑫. All rights reserved.
//

#import "Person.h"
#import <objc/runtime.h>


@interface Person ()

@property (nonatomic, strong) NSString *privateJJ;

@end

@implementation Person


-(instancetype)initWithDictionary:(NSDictionary *)dic{
    
    if (self = [super init]) {
        
        NSMutableArray *keys          = [NSMutableArray array];
        NSMutableArray *attributes    = [NSMutableArray array];
        
        unsigned int outCount;
        objc_objectptr_t *propertys   = class_copyPropertyList([self class], &outCount);
        for (int i = 0; i < outCount; i ++) {
            objc_objectptr_t property = propertys[i];
            
            //通过property_getName来获取key
            NSString *propertyName    = [NSString stringWithCString:property_getName(property) encoding:NSUTF8StringEncoding];
            [keys addObject:propertyName];
            
            //通过property_getAttributes获取value
            NSString *attributeName   = [NSString stringWithCString:property_getAttributes(property) encoding:NSUTF8StringEncoding];
            [attributes addObject:attributeName];
        }
        
        //释放propertys指向的内存
        free(propertys);
        
        //根据属性给key来赋值   continue:终止当前循环，继续进行下一个循环
        for (NSString *key in keys) {
            if ([dic valueForKey:key] == nil)  continue;
            [self setValue:[dic valueForKey:key] forKey:key];
        }
        
    }
    return self;
}




//重写该类的initWithCoder和encodeWithCoder方法来进行归档和反归档
- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super init];
    if (self) {
        unsigned int outCount;
        Ivar *ivars = class_copyIvarList([self class], &outCount);
        for (int i = 0; i < outCount; i ++) {
            Ivar ivar = ivars[i];
            NSString *key = [NSString stringWithUTF8String:ivar_getName(ivar)];
            [self setValue:[coder decodeObjectForKey:key] forKey:key];
        }
    }
    return self;
}


- (void)encodeWithCoder:(NSCoder *)coder
{
    unsigned int outCount;
    Ivar *ivars = class_copyIvarList([self class], &outCount);
    for (int i = 0; i < outCount; i++) {
        Ivar ivar = ivars[i];
        NSString *key = [NSString stringWithUTF8String:ivar_getName(ivar)];
        
        [coder encodeObject:[self valueForKey:key] forKey:key];
    }
}












@end
