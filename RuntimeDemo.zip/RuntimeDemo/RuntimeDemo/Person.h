//
//  Person.h
//  RuntimeDemo
//
//  Created by 刘鑫 on 2018/12/19.
//  Copyright © 2018 刘鑫. All rights reserved.

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) int     age;






- (instancetype)initWithDictionary:(NSDictionary *)dic;

@end
NS_ASSUME_NONNULL_END

