//
//  ViewController.m
//  RuntimeDemo
//
//  Created by 刘鑫 on 2018/12/19.
//  Copyright © 2018 刘鑫. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
#import <objc/runtime.h>


@interface ViewController ()


@end

//增加的属性名
static NSString *const addName = @"addName";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    //[self jsonToModel];
    
    
    //[self getPrivateProperty];
    
    
    //[self getAssociatePropertyOnView];
    
    
    //先调用方法互换，再调用原本方法看结果
    [self exchangeMethod];
    [self origiMethod];
}



#pragma mark ------------------- json转model -------------------
-(void)jsonToModel{
    NSDictionary *dic = @{@"name":@"张三",
                          @"age":@19
                          };
    Person *model = [[Person alloc] initWithDictionary:dic];
    NSLog(@"-------名字是:%@, -------年龄是:%d",model.name, model.age);
}




#pragma mark ------------------- 归档和反归档 -------------------
/*
 *利用runtime提供的函数遍历model的所有属性，并对属性进行encode和decode操作
 *详情见基类Person.m
 */




#pragma mark ------------------- 访问私有变量 -------------------
/*
 *私有变量放在.m文件中，我们只要知道该私有变量的名称，就可以通过runtime来获取私有变量，
 *进而通过getIvar来获取他的值
 */
-(void)getPrivateProperty{
    NSDictionary *dic = @{@"name":@"张三",
                          @"age":@19,
                          @"privateJJ":@"私有变量"
                          };
    Person *model = [[Person alloc] initWithDictionary:dic];
    Ivar ivar = class_getInstanceVariable([model class], "_privateJJ");
    NSString *privateValue = object_getIvar(model, ivar);
    NSLog(@"----------私有变量的值为:%@",privateValue);
}





#pragma mark ------------------- 给对象关联属性 -------------------
/*
 *关联属性和对应的值:objc_setAssociatedObject
 *获取关联属性对应的值:objc_getAssociatedObject
 *删除关联的属性:objc_removeAssociatedObjects
 */
-(void)getAssociatePropertyOnView{
    UIView *rectView          = [UIView new];
    [self.view addSubview:rectView];
    rectView.backgroundColor  = [UIColor blueColor];
    rectView.frame            = CGRectMake(0, 0, 70, 70);
    rectView.center           = self.view.center;
    
    objc_setAssociatedObject(rectView, &addName, @"这是添加属性对应的值", OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    NSLog(@"-------获取到关联属性的值为:%@",objc_getAssociatedObject(rectView, &addName));
}





#pragma mark ------------------- 方法互换 -------------------
/*
 *每个类都会维护一个方法列表，该表包含sel和其实现imp的关系。方法交换做的事情就是把sel和imp
 *之间的关系断开，并和新的imp产生对应关系
 */
-(void)exchangeMethod{
    SEL orisel = @selector(origiMethod);
    Method orimethod = class_getInstanceMethod([self class], orisel);
    
    SEL mysel        = @selector(myMethod);
    Method mymethod = class_getInstanceMethod([self class], mysel);
    
    bool addSuc = class_addMethod([self class], orisel, method_getImplementation(mymethod), method_getTypeEncoding(mymethod));
    if (addSuc) {
        class_replaceMethod([self class], mysel, method_getImplementation(orimethod), method_getTypeEncoding(orimethod));
    }else{
        method_exchangeImplementations(orimethod, mymethod);
    }
}


-(void)origiMethod{
    NSLog(@"这是原本方法的实现111111");
}


-(void)myMethod{
    NSLog(@"这是我的方法的实现222222");
}

@end
