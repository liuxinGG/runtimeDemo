//
//  main.m
//  RuntimeDemo
//
//  Created by 刘鑫 on 2018/12/19.
//  Copyright © 2018 刘鑫. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
